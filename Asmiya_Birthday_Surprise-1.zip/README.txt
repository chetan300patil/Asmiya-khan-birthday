ASMIYA'S BIRTHDAY SURPRISE

1. Extract this ZIP.
2. Open index.html in a browser to preview the birthday page.
3. To make it a public link, easiest is GitHub Pages:
   - Create a new GitHub repository (e.g. asmiya-birthday).
   - Upload index.html to the repository root.
   - Open Settings > Pages.
   - Under Build and deployment, choose "Deploy from a branch".
   - Choose branch main and folder /(root), then Save.
   - Wait a minute; GitHub will show your website URL in Settings > Pages.
4. Send that URL to Asmiya on WhatsApp.

This page is a single-file website. You can edit the message directly inside index.html.
